// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

// ─────────────────────────────────────────────────────────────
//  AMOKToken.sol v0.2 — Soulbound solidarity token
//  Fix: _update override correctly blocks ALL transfers
//       while allowing mint (from == 0) and burn (to == 0)
// ─────────────────────────────────────────────────────────────

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/utils/Base64.sol";
import "@openzeppelin/contracts/utils/Strings.sol";

contract AMOKToken is ERC721 {
    using Strings for uint256;

    address public immutable amok;

    struct TokenData {
        bytes32 nullifier;
        uint256 pledgedAt;
    }

    mapping(uint256 => TokenData) public tokenData;

    error SoulboundToken();
    error OnlyAMOK();
    error AlreadyMinted();

    constructor(address _amok) ERC721("AMOK Solidarity Token", "AMOK") {
        amok = _amok;
    }

    function mint(address to, uint256 tokenId, bytes32 nullifier) external {
        if (msg.sender != amok)         revert OnlyAMOK();
        if (_ownerOf(tokenId) != address(0)) revert AlreadyMinted();
        tokenData[tokenId] = TokenData(nullifier, block.timestamp);
        _mint(to, tokenId);
    }

    // ── Soulbound: block transfers, allow mint + burn ─────────
    function _update(address to, uint256 tokenId, address auth)
        internal override returns (address from)
    {
        from = super._update(to, tokenId, auth);
        // from == address(0) → mint (ok)
        // to   == address(0) → burn (ok)
        // both non-zero      → transfer (blocked)
        if (from != address(0) && to != address(0)) revert SoulboundToken();
    }

    // ── Fully on-chain SVG metadata ───────────────────────────
    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        TokenData memory td = tokenData[tokenId];

        string memory svg = string(abi.encodePacked(
            '<svg width="400" height="400" viewBox="0 0 160 160" xmlns="http://www.w3.org/2000/svg">',
            '<circle cx="80" cy="80" r="80" fill="#020f0a"/>',
            '<circle cx="80" cy="80" r="78" fill="none" stroke="#1D9E75" stroke-width="1"/>',
            '<ellipse cx="80" cy="80" rx="50" ry="50" fill="none" stroke="#0F6E56" stroke-width="0.6"/>',
            '<ellipse cx="80" cy="80" rx="50" ry="25" fill="none" stroke="#0F6E56" stroke-width="0.6"/>',
            '<line x1="80" y1="30" x2="80" y2="130" stroke="#0F6E56" stroke-width="0.6"/>',
            '<line x1="30" y1="80" x2="130" y2="80" stroke="#0F6E56" stroke-width="0.6"/>',
            '<path d="M10 80 Q80 20 150 80 Q80 140 10 80Z" fill="#04342C" stroke="#5DCAA5" stroke-width="2"/>',
            '<ellipse cx="80" cy="80" rx="28" ry="28" fill="#1D9E75"/>',
            '<ellipse cx="80" cy="80" rx="16" ry="16" fill="#020f0a"/>',
            '<ellipse cx="73" cy="73" rx="5" ry="5" fill="#9FE1CB" opacity="0.6"/>',
            '<text x="80" y="132" font-family="monospace" font-size="7" fill="#0F6E56" text-anchor="middle">',
            'AMOK-', tokenId.toString(),
            '</text>',
            '<text x="80" y="144" font-family="monospace" font-size="5" fill="#085041" text-anchor="middle">keepAIon.com</text>',
            '</svg>'
        ));

        string memory json = Base64.encode(bytes(string(abi.encodePacked(
            '{"name":"AMOK #', tokenId.toString(), '",',
            '"description":"Zero-knowledge solidarity token. Proves keepAIon pledge. Identity concealed.",',
            '"image":"data:image/svg+xml;base64,', Base64.encode(bytes(svg)), '",',
            '"attributes":[',
                '{"trait_type":"Token ID","value":"',    tokenId.toString(),          '"},',
                '{"trait_type":"Nullifier","value":"0x', _toHex(td.nullifier),        '"},',
                '{"trait_type":"Pledged","value":"',     td.pledgedAt.toString(),      '"},',
                '{"trait_type":"Protocol","value":"keepAIon AMOK v0.2"},',
                '{"trait_type":"Transfer","value":"soulbound"},',
                '{"trait_type":"Identity","value":"concealed"}',
            ']}'
        ))));

        return string(abi.encodePacked('data:application/json;base64,', json));
    }

    function _toHex(bytes32 data) internal pure returns (string memory) {
        bytes memory alpha = "0123456789abcdef";
        bytes memory str   = new bytes(64);
        for (uint i = 0; i < 32; i++) {
            str[i*2]   = alpha[uint(uint8(data[i] >> 4))];
            str[i*2+1] = alpha[uint(uint8(data[i] & 0x0f))];
        }
        return string(str);
    }
}
