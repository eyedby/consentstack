# The Consent Stack
## A White Paper on the Consolidation of aiOut, keepAIon, Δ9, AMOK, and 4DNFT

**Version 0.1 · eyedby · June 2026**

---

## Abstract

The internet is experiencing a consent crisis. AI systems process, analyze, and act on human data without meaningful permission. Platforms monetize creative work without tracking or compensating the creators who made it. Identity is either fully exposed or fully anonymous — with no middle ground for private but verifiable participation.

This white paper describes **The Consent Stack** — a five-layer protocol ecosystem that addresses these failures simultaneously. Each layer is independently useful. Together they form the first complete infrastructure for consent-first participation in AI, web3, and digital media.

The five layers are:

| Layer | Domain | Function |
|---|---|---|
| **Rights** | aiOut.me | Public opt-out registry and legal record |
| **Builders** | keepAIon.com | Developer pledge and ethical AI credential |
| **Proof** | AMOK | Zero-knowledge proof of credential |
| **Economy** | Δ9 | Utility token gating and governance |
| **Media** | 4DNFT.com | On-chain artist play and share tracking |

---

## 1. The Problem

### 1.1 AI without consent

AI systems are deployed against people without their knowledge or permission. Facial recognition identifies individuals in public spaces. Hiring algorithms screen candidates before a human reads their resume. Customer service bots process sensitive data under the guise of helpfulness. In each case, the person being processed has not consented — and in most jurisdictions, has no legal recourse.

The absence of consent is not accidental. It is structural. Consent is friction. Friction reduces conversion. Businesses optimise for conversion. The result is a systematic erosion of the right to be left alone.

### 1.2 Builders without credibility

Developers who want to build AI responsibly have no way to prove it. There is no credential for ethical AI development. A builder can write a blog post, publish a policy document, or add a disclaimer to their terms of service — but none of these are verifiable, portable, or privacy-preserving.

The consequence is a race to the bottom. Without a meaningful signal of ethical commitment, responsible builders are indistinguishable from irresponsible ones. The market cannot reward good behaviour it cannot see.

### 1.3 Identity without privacy

Existing identity systems force a binary choice: full exposure or full anonymity. A developer who wants to publicly commit to ethical AI must either reveal their identity (exposure) or remain silent (anonymity). There is no mechanism for saying "I signed this pledge" without revealing who signed it.

Zero-knowledge proofs solve this mathematically. But they have not been applied to the problem of builder credentialing — until now.

### 1.4 Creative work without provenance

Music, art, and video are shared millions of times per day. The creator of a track rarely knows where it has been played, by whom, or how many times. Royalty systems are opaque, slow, and controlled by platforms with conflicting interests. Attribution breaks the moment content leaves its origin platform.

NFTs promised to fix this but delivered speculation instead of provenance. The missing piece is not ownership — it is tracking. A living NFT that records every play and share on-chain, in real time, is the infrastructure creative work has always needed.

---

## 2. The Consent Stack

### 2.1 Architecture overview

```
┌─────────────────────────────────────────────────────────────┐
│                    User / Developer / Artist                 │
└──────────┬──────────────┬──────────────┬───────────────────┘
           │              │              │
    ┌──────▼──────┐ ┌─────▼──────┐ ┌───▼────────────┐
    │  aiOut.me   │ │keepAIon.com│ │   4DNFT.com    │
    │ Rights layer│ │Builder layer│ │  Media layer   │
    └──────┬──────┘ └─────┬──────┘ └───┬────────────┘
           │              │             │
           └──────┬────────┘            │
                  │                     │
           ┌──────▼──────┐             │
           │    AMOK     │◄────────────┘
           │  ZKP layer  │
           └──────┬──────┘
                  │
           ┌──────▼──────┐
           │     Δ9      │
           │Economy layer│
           └─────────────┘
```

Each layer interacts with the others through defined interfaces. A user can participate in any single layer without the others. But full participation in the stack creates compounding value — a verified, private, economically incentivised record of consent and creative provenance.

### 2.2 Layer 1 — aiOut.me (Rights)

**Purpose:** Public opt-out registry and legal record for AI consent.

**Mechanism:** Individuals add their name to a public registry asserting their right to opt out of AI processing. The registry is append-only, publicly verifiable, and jurisdiction-agnostic.

**Legal strategy:** The registry creates a documented record of consent refusal that can be cited in legal proceedings, regulatory submissions, and policy advocacy. As AI regulation develops globally — the EU AI Act, proposed US federal frameworks, emerging APAC standards — a documented opt-out record provides standing for individuals and ammunition for advocates.

**Integration points:**
- Registry entries can be linked to AMOK tokens for pseudonymous but verifiable opt-out
- Δ9 governance votes can direct legal strategy and jurisdiction prioritisation
- 4DNFT artists can assert aiOut membership to establish consent-first licensing terms

### 2.3 Layer 2 — keepAIon.com (Builders)

**Purpose:** Developer pledge and ethical AI credential for the pro-AI, pro-regulation builder community.

**Mechanism:** Developers sign a public pledge committing to transparency, consent, and accountability in AI development. The pledge is not a restriction — it is a positive assertion of values. Builders who sign are not anti-AI. They are pro-AI and pro-getting-it-right.

**The pledge:**
> "I commit to building AI tools with transparency, consent, and accountability. I support sensible regulation that protects people without killing progress. I keep AI on — and I build it right."

**Credential:** Signing the pledge generates an AMOK zero-knowledge proof (see Layer 3). The credential is portable, verifiable, and privacy-preserving. It can be displayed in a GitHub README, embedded in a site footer, or verified on-chain.

**Community:** keepAIon is the counter-narrative to both AI panic and AI recklessness. It occupies the credible centre — the position of builders who have thought hard about what they are building and why.

### 2.4 Layer 3 — AMOK (Zero-Knowledge Proof)

**Purpose:** Privacy-preserving credential layer connecting all other layers.

**Name:** Autonomous Movement Of Knowledge.

**Mechanism:** AMOK uses a zero-knowledge proof circuit (Noir / Barretenberg) to generate a verifiable credential without revealing the holder's identity. The proof asserts: "I signed the keepAIon pledge" without revealing who signed it.

**Technical design:**

```
Private inputs (never revealed):
  secret             — developer's passphrase, hashed locally
  github_handle_hash — hash of github.com/username

Public inputs (on-chain verifiable):
  commitment  = pedersen(secret, github_handle_hash)
  nullifier   = pedersen(secret, 0)
  pledge_root = merkle root of all commitments

Proof: knowledge of secret such that commitment and
       nullifier are correctly derived and commitment
       is a member of the pledge merkle tree
```

**Subscription model:** AMOK credentials are not permanent. They require the holder to maintain a minimum Δ9 balance on Solana. This creates ongoing economic alignment — the credential stays active as long as the holder participates in the ecosystem economy.

**Soulbound token:** Each AMOK credential is minted as a soulbound ERC-721 on Base. It cannot be transferred. Token metadata contains only the nullifier hash and timestamp — no wallet address, no identity.

### 2.5 Layer 4 — Δ9 (Economy)

**Purpose:** Utility token providing economic incentives and governance across the stack.

**Chain:** Solana SPL (primary) with Base bridge for AMOK contract interaction.

**Functions:**

| Function | Mechanism |
|---|---|
| AMOK subscription | Hold minimum Δ9 balance → AMOK credential stays active |
| Governance | Vote on aiOut legal strategy, keepAIon pledge updates, 4DNFT royalty parameters |
| 4DNFT premium | Δ9 holders unlock advanced play/share analytics and enhanced royalty splits |
| Ecosystem payments | Pay for premium features across all domains |

**Token design principles:**
- No burn mechanics — Δ9 is a participation signal, not a deflationary asset
- Holding is sufficient — no complex staking required for base access
- Governance weight proportional to holding duration, not just amount
- Treasury managed by on-chain governance after initial launch period

### 2.6 Layer 5 — 4DNFT (Media)

**Purpose:** On-chain play and share tracking for artist offerings.

**The fourth dimension:** Traditional NFTs capture three dimensions of creative work — ownership, authenticity, and scarcity. 4DNFT adds the fourth dimension: **provenance over time**. Every play, every share, recorded on-chain as it happens.

**Mechanism:**
- Artists mint offerings as ERC-1155 tokens on Base
- Platform integrations call `recordPlay()` and `recordShare()` on each interaction
- Play and share events are stored on-chain with pseudonymous listener/sharer identities
- ERC-2981 royalties flow automatically to artists on secondary sales
- AMOK-verified artists receive a verified badge in their token metadata

**Privacy design:** Listener and sharer identities are hashed before recording. The chain knows a play happened — it does not know who played it. This is consent by design, consistent with the aiOut framework.

**Royalty architecture:**
```
Sale proceeds
  └─ Artist royalty (default 10%, configurable per offering)
  └─ Platform fee (2.5%)
  └─ Δ9 staker share (1%)
  └─ Remaining to seller
```

---

## 3. Integration Architecture

### 3.1 Cross-layer flows

**Flow 1: Developer signs pledge**
```
1. Developer visits keepAIon.com
2. Enters GitHub handle + passphrase
3. AMOK generates ZKP in browser (private inputs never leave device)
4. Commitment registered on Base (no identity revealed)
5. ZK proof submitted → AMOK soulbound token minted
6. Developer holds Δ9 on Solana to keep credential active
7. Badge embeds in GitHub README with verifiable link
```

**Flow 2: Artist mints offering**
```
1. Artist visits 4DNFT.com
2. Connects wallet, uploads media to IPFS
3. Calls mintOffering() with title, type, IPFS hash, royalty config
4. If artist holds valid AMOK token → amokVerified = true in metadata
5. Offering minted as ERC-1155 on Base
6. Platform integrations begin recording plays and shares
7. Royalties flow on secondary sales via ERC-2981
```

**Flow 3: Listener plays a track**
```
1. Listener discovers offering on integrated platform
2. Platform calls recordPlay(tokenId, duration, sessionHash)
3. sessionHash = keccak256(listenerAddress + salt) — listener pseudonymous
4. Play event recorded on-chain
5. Artist play count increments (visible in token metadata)
6. If listener holds Δ9 → premium features unlocked
```

**Flow 4: Governance vote**
```
1. Δ9 holder connects Solana wallet
2. Votes on proposal (aiOut legal strategy, keepAIon pledge version, 4DNFT fee params)
3. Vote weight = Δ9 balance × holding duration multiplier
4. Passed proposals executed by multisig or on-chain executor
```

### 3.2 Domain routing

All five domains serve the same codebase. A single `index.html` detects `window.location.hostname` and renders the appropriate theme and content. GoDaddy domain masking ensures each domain preserves its identity in the browser address bar while pointing to the same hosted file.

```
aiout.me      → theme-aiout    (red/black, rights movement)
keepaion.com  → theme-keepaion (green, builder pledge)
delta9.com    → theme-delta9   (gold, utility token)
4dnft.com     → theme-4dnft   (purple, artist NFTs)
amok.*        → theme-keepaion (green, ZKP credential)
```

---

## 4. Technical Stack

| Component | Technology | Chain / Platform |
|---|---|---|
| ZK circuit | Noir >= 0.30 | — |
| ZK backend | Barretenberg (UltraPlonk) | — |
| AMOK contract | Solidity 0.8.20 | Base |
| 4DNFT contract | Solidity 0.8.20 (ERC-1155) | Base |
| Δ9 token | SPL Token Program | Solana |
| Cross-chain oracle | Pyth / Wormhole | Solana ↔ Base |
| Frontend | Vanilla JS, IBM Plex Mono | GoDaddy Aero |
| Repo | eyedby/keepaion | GitHub |
| Deploy | GitHub Actions → cPanel | GoDaddy |

---

## 5. Roadmap

### Phase 1 — Foundation (now)
- [ ] aiOut.me live with opt-out registry
- [ ] keepAIon.com live with AMOK pledge flow (browser ZKP demo)
- [ ] Unified index.html deployed across all domains
- [ ] eyedby/keepaion repo clean and structured

### Phase 2 — On-chain (Q3 2026)
- [ ] AMOK contract deployed to Base Sepolia
- [ ] UltraVerifier generated from Noir circuit
- [ ] AMOK soulbound tokens minting on testnet
- [ ] Δ9 SPL token deployed on Solana devnet

### Phase 3 — 4DNFT (Q4 2026)
- [ ] 4DNFT contract deployed to Base
- [ ] Artist onboarding flow live at 4DNFT.com
- [ ] Platform integrations for play/share recording
- [ ] Royalty splits active

### Phase 4 — Economy (Q1 2027)
- [ ] Δ9 mainnet launch on Solana
- [ ] AMOK subscription model live (hold Δ9 → credential active)
- [ ] Cross-chain oracle for Solana balance verification on Base
- [ ] Governance module live

### Phase 5 — Scale (2027)
- [ ] aiOut legal filings in EU, US, AU jurisdictions
- [ ] keepAIon developer directory with verifiable AMOK badges
- [ ] 4DNFT streaming platform integrations
- [ ] Δ9 governance controlling treasury and protocol parameters

---

## 6. Legal Considerations

The aiOut opt-out registry does not constitute legal advice and does not guarantee any specific legal outcome. Its value is in creating a documented record of expressed intent, which may be relevant in legal proceedings or regulatory contexts depending on jurisdiction.

AMOK zero-knowledge proofs do not guarantee anonymity in all circumstances. The system is designed to minimise identity exposure, not eliminate it absolutely. Users should understand the privacy model before participation.

Δ9 token holders should be aware that utility tokens may be subject to regulatory scrutiny in their jurisdiction. The Δ9 token is designed as a utility token, not a security. Legal classification may vary.

---

## 7. Contact

- **GitHub:** github.com/eyedby/keepaion
- **aiOut:** aiout.me
- **keepAIon:** keepaion.com
- **4DNFT:** 4dnft.com
- **X:** @keepaion

---

*The Consent Stack · v0.1 · June 2026*
*building by builders · we thought this through*
